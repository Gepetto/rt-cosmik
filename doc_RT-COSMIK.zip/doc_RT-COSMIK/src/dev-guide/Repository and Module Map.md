# Repository and Module Map

RT-COSMIK is the main repository. However, to help calibrate the cameras, there's an helper repository **two repositories**. Current as of the [`mathilde` branch](https://github.com/Gepetto/rt-cosmik/tree/mathilde) of rt-cosmik — a superset of `offline-paper` (which this chapter previously described), adding `run_pipeline_threaded.py`, the `compare.py` evaluation tool, and the `run_multiple_*.sh` sweep scripts — and [cams_calibration](https://github.com/Gepetto/cams_calibration) (the LAAS-internal canonical copy lives on GitLab; this is the GitHub mirror).

## cams_calibration — produces the calibration files RT-COSMIK reads

- **`scripts/calibrate_cameras.py`** / **`scripts/set_world_frame.py`** / **`scripts/calibrate_from_human.py`** — see [Camera Calibration Procedure](../functioning/Camera%20Calibration%20Procedure.md) for the workflow and CLI.
- **`utils/calib_utils.py`** — checkerboard detection/geometry, `describe_camera_placement`. **`utils/human_calib.py`** — supports the walking-person method. **`utils/settings.py`** — board/wand physical dimensions.

## rt-cosmik (`mathilde` branch)

```
settings.py                  Root Settings dataclass: ik_type, mhe_backend, mhe_profile,
                              cameras, YOLO/NLF model paths, filter params, save flags.
config/cam_params/           Local calibration staging (gitignored; installed here by
                              cams_calibration's --install).
docs/acados_mhe_ik.md        Design + validation notes for the parameterized acados
                              MHE-IK work — the source for most of the IK Solvers chapter.
ocp/<backend>/<profile>/     Generated IK solver artefacts (gitignored) + ocp_manifest.json.
                              Not checked-in source — see IK Solvers for what's in them.

scripts/bash/
  fetch_models.sh            NLF/YOLO weights + one TensorRT engine per camera count.
  setup_env.sh                 rtcosmik onto sys.path via a .pth file (for the ROS overlay,
                              whose setuptools predates PEP 660); --acados builds acados too.
  run_multiple_pipeline.sh   Shell loop: every participant × task × camera-set under a
                              dataset's videos/, via run_pipeline_threaded.py.
  run_multiple_eval.sh       Shell loop: aggregates per-run logs into RMSE plots via compare.py.

scripts/python/core/         run_cameras.py, run_nlf_inference.py, run_triangulation.py,
                              run_pipeline.py, run_pipeline_threaded.py, run_ocp_codegen.py
                              — see Running Modes and CLI Reference.
scripts/python/eval/         compare.py, compare_to_mocap.py, frame_drops.py.

src/rtcosmik/
  camera/        camera.py (Camera, DisplayConsumer — separate OS processes), sources.py
                 (FFmpegSource — capture goes through ffmpeg, not cv2.VideoCapture, whose
                 V4L2 backend ignores CAP_PROP_BUFFERSIZE), cam_utils.py (calibration
                 loading/chaining, describe_camera_placement, resolve_camera_ids).
  config_loader.py   Resolves --dataset/--participant/--task (or explicit --cam-params/
                     --trial-dir/--subject) into one trial's config.
  ergonomics/    reba.py, reba_offline.py — standalone REBA scoring, not wired into
  human_model/   model_utils.py — builds/scales the Pinocchio biomechanical model.
  ik/            ik.py (RT_IK / RT_SWIKA_FATROP / RT_SWIKA_ACADOS), ocp_model.py
                 (parameterize/fingerprint/SOLVER_PROFILES/manifest — see IK Solvers).
  pipeline/      pipeline.py (PipelineProcess), solver.py (HumanSolver — dispatches per
                 settings.ik_type/mhe_backend).
  saver/         csv_saver.py, video_saver.py, recorder.py, hotkeys.py.
  triangulation/ triangulation.py (DLT, triangulate_points, fuse_camera_poses3d).
  viewer/        viewer.py (ViserRobotVisualizer/ViserViewer, MeshcatViewer, NoOpViewer,
                 Viewer dispatcher), async_display.py (keeps display off the pipeline's
                 critical path — see Threading and Performance below), debug_visuals.py.

tests/
  unit/          Mirrors src/ (camera, ergonomics, ik, saver, triangulation, viewer).
  benchmark/     benchmark_mhe_ik_backends.py, benchmark_mmpose_*.py,
                 benchmark_triangulation.py, validate_ocp_params.py.
  full/          Integration fixture: short recordings + calibration + expected output.
```

## Threading and Performance

Each camera runs as its own `Camera` process, writing into shared-memory buffers read by `PipelineProcess`. `run_pipeline_threaded.py` splits pose/IK across three named threads connected by queues — `reader` (pulls frames), `gpu_worker` (NLF/YOLO), `ik_worker` (triangulation, filtering, IK) — each timed separately (median/p95/max), with a `warm_steady_state_s` split so warm-up doesn't distort steady-state throughput.

Visualization is not the bottleneck: `async_display.py`'s threaded Meshcat updates were introduced after measuring visualization at **4.7 ms of a 29.4 ms offline frame (16% of the budget)** — moving it off the critical path was the difference between 34 and 40 fps on a 40 fps dataset. Pose estimation (NLF) dominates total latency; IK is comparatively cheap (see [IK Solvers](IK-solvers.md)) — that's where optimization effort pays off most.

The live pipeline logs a line like `[TIME]  37.2 turns/s | loop  26.9 ms (pose 18.9, ik  5.1) | kept  93% of camera frames` every couple of seconds, plus a per-stage summary on exit. `kept %` is how many camera frames were actually processed; use `scripts/python/eval/frame_drops.py` to see *where* frames were lost.