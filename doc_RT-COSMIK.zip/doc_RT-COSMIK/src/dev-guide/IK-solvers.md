# IK Solvers

`settings.ik_type` picks the IK method (`ik/ik.py`):

- **`"sbs"`** — sample-by-sample, one frame at a time, via CasADi/Ipopt (`RT_IK`).
- **`"mhe"`** — moving-horizon estimation over a sliding window of `settings.N` frames (default 10), via `settings.mhe_backend`: `"fatrop"` (the validated reference) or `"acados"`.

There is one branch for both `mhe` backends — no separate acados-only branch to track.

## Solver options

**Fatrop** (`RT_SWIKA_FATROP.DEFAULT_SOLVER_OPTIONS`):
```python
{"print_level": 0, "mu_init": 1e-1, "tol": 1e-4}
```

**Acados** (`RT_SWIKA_ACADOS.DEFAULT_SOLVER_OPTIONS`) — baked into the *generated* code rather than passed at runtime, so different speed/accuracy profiles can be generated and compared side by side, and whichever combination is used is included in the generated artefact's fingerprint (so switching profiles is caught rather than silently reusing a stale `.so`):

```python
DEFAULT_SOLVER_OPTIONS = {
    "qp_solver": "PARTIAL_CONDENSING_HPIPM",
    "hessian_approx": "GAUSS_NEWTON",
    "integrator_type": "DISCRETE",
    "nlp_solver_type": "SQP-RTI",
    "nlp_solver_max_iter": 50,
    "qp_solver_iter_max": 3,
    "tol": 1e-3,
    "globalization": "FIXED_STEP",
}
```

| Option | Value | What it controls |
| --- | --- | --- |
| `qp_solver` | `PARTIAL_CONDENSING_HPIPM` / `FULL_CONDENSING_HPIPM` | The QP solver used for the inner QP subproblem at each SQP iteration. |
| `hessian_approx` | `GAUSS_NEWTON` | Approximates the Hessian via Gauss-Newton instead of computing the exact Hessian — cheaper per iteration. |
| `integrator_type` | `DISCRETE` | The dynamics are already discrete, so no continuous-time integration step runs inside the solver. |
| `nlp_solver_type` | `SQP` / `SQP-RTI` | `SQP` linearizes and iterates to convergence; `SQP-RTI` linearizes once per solver call (Real-Time Iteration) rather than iterating to full NLP convergence, trading some accuracy for a bounded, predictable per-call cost. |
| `nlp_solver_max_iter` | `50` | Outer SQP-level iteration cap. |
| `qp_solver_iter_max` | `3` | Inner QP solver's own iteration cap, applied per SQP iteration — distinct from `nlp_solver_max_iter` above. |
| `tol` | `1e-3` | Solver convergence tolerance. |
| `globalization` | `MERIT_BACKTRACKING` / `FIXED_STEP` | `FIXED_STEP` takes the same size step every iteration; `MERIT_BACKTRACKING` runs a line search to size each step. |

## Speed/accuracy profiles

`settings.mhe_profile` (`"realtime"`/`"accurate"`) overrides a few of the above per backend, defined in `ocp_model.SOLVER_PROFILES`:

```python
SOLVER_PROFILES = {
    "acados": {
        "realtime": {"nlp_solver_type": "SQP_RTI"},
        "accurate": {"nlp_solver_type": "SQP", "nlp_solver_max_iter": 10, "tol": 1e-6},
    },
    "fatrop": {
        "realtime": {"max_iter": 10, "tol": 1e-4},
        "accurate": {"max_iter": 100, "tol": 1e-6},
    },
}
```

Measured (120 frames of real marker data, N=10 — see `docs/acados_mhe_ik.md` §9 for the full methodology):

| config | median | p95 | max | marker RMSE |
| --- | --- | --- | --- | --- |
| **acados `realtime` (SQP_RTI)** | 4.85 ms | 5.9 ms | 8.7 ms | 1.02 mm |
| acados `accurate` (SQP, it=10, tol=1e-6) | 12.31 ms | 43.2 ms | 45.8 ms | 1.03 mm |
| fatrop `realtime` (it=10, tol=1e-4) | 26.86 ms | 28.8 ms | 46.5 ms | 1.09 mm |
| fatrop `accurate` (it=100, tol=1e-6) | 35.70 ms | 41.0 ms | 45.7 ms | 1.07 mm |

`SQP_RTI` matches fully-converged SQP on marker fit with slightly *less* jitter, at a fraction of the tail latency — not the usual real-time/accuracy trade-off, which is why it's the `realtime` default. The profile is baked into the generated code, so switching it needs regenerating (`run_ocp_codegen.py`).

## Where each solver spends its time

Profiled with flamegraphs via `py-spy`: **Fatrop**'s dominant cost is CasADi `SXFunction` Hessian evaluation. **Acados**, under the `FIXED_STEP`/`SQP-RTI` configuration above (no line search, Gauss-Newton Hessian), hasn't had its own bottleneck reprofiled since — check with the latest version before assuming it mirrors Fatrop's.

Other reference numbers from `docs/acados_mhe_ik.md` (different hardware/data, so relative not absolute): fatrop (python) ~31 ms / 9.93 mm, acados default ~10 ms / 4.29 mm (spikes to ~200 ms on hard frames), acados `max_iter=3` ~5 ms / ~3.7 mm. Acados's `sqp_iter` is data-dependent — cap it (`settings.mhe_max_iter`, distinct from the acados-native `nlp_solver_max_iter` above) for a bounded real-time budget.

## One solver serves every person

The OCP is parameterized by the subject's geometry rather than baking a specific body into the generated code, so calibrating a new subject sets parameters in under a millisecond instead of recompiling mid-session (`ocp_model.parameterize`/`extract_params`) — verified to reproduce the previous per-subject-baked FK exactly (max diff `0.0`), both at a subject's own parameters and cross-subject. `ocp_manifest.json` records everything baked into an artefact and is checked on load, refusing (and naming what changed) rather than silently solving with a mismatched model.

## A specific Acados runtime pitfall

`ACADOS_SOURCE_DIR` and its `lib/*.so` need to be on the loader path as **absolute paths** — `scripts/bash/setup_env.sh --acados` handles this (and can build acados from source if missing). Installing `acados_template` via pip can also pull in a pip `casadi` wheel that shadows a from-source CasADi install and breaks `import pinocchio.casadi` — install with `--no-deps`, or `pip uninstall -y casadi` to recover. See [Environment Setup](Environment.md).