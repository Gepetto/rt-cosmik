# Known Issues and Workaround
All items listed below have been validated against the mathilde branch.

## Fixed, with a specific cause worth knowing

| Issue | Symptom | Root cause / fix |
| --- | --- | --- |
| Acados silently regenerated on every load | Every load took ~55 s instead of reusing the compiled artefact | `is_code_reuse_possible` → `compare_ocp_formulations` raised `AttributeError` because acados' own JSON round-trip drops `tol`/`qp_tol`/`qp_solver_tol_*`; a bare `except Exception: return False` forced a rebuild every time. Fixed by `check_reuse_possible=False` on load, relying on the manifest check instead. 55.24 s → 0.13 s. |
| Solver state leaked between subjects | Same solver, same subject, same inputs, run twice — differed by 3.67e-02 rad | Acados keeps its iterate/duals across `solve()` calls for warm-starting; the first frames after a subject change were pulled toward the previous person's solution. Fixed: `set_model_params` now calls `reset()`. |
| fatrop's `code="c"` codegen path | Dead: reachable only through a broken script, wrote `ocp_O3.so` into the working directory, shelled out to `gcc` with no error checking | Restored with both bugs fixed. |
| Thorax visual misplaced | Chest renders below the thoracic joint, worse for taller subjects | Upstream `example-robot-data` model issue; kinematics unaffected, only the viewer's rendering. Fix on the `fix/thorax-visual-scale-and-origin` fork branch. |
| ~170° world-frame misalignment          | Large, clean-looking angular offset                       | Caused by inconsistent ArUco marker placement across sessions, not a math bug.                                                                                |
| YOLO setup script early exit            | Setup script fails partway                                | Bug in the model-installation bash script. Fixed, and the script now also skips re-download/reconfiguration when batch size/dimensions already match.         |
| NVIDIA driver/DKMS mismatch             | CUDA errors after host reboot                             | Kernel update left the DKMS module mismatched with the running kernel. Fixed by rebuilding/reinstalling against the current kernel.                           |
| Stale Xauthority in Docker              | Black/missing visualization window                        | Xauthority file went stale on a read-only ext4 bind mount. Workaround: `/tmp/.Xauthority` + export in `~/.bashrc`.                                            |

## Known, pre-existing, not yet hit in practice

Mannequin appears to jitter/shake despite stable tracking, possible sign convention bug in `ManualViserRobotVisualizer`. May still exist, fix untested. 

## Accuracy trade-offs, not bugs

- `calibrate_from_human.py` is a deliberately rougher fallback (~3% of baseline error vs. ~5 mm for a checkerboard) — see [Camera Calibration Procedure](../functioning/Camera%20Calibration%20Procedure.md).
- Acados accuracy is data-dependent — `sqp_iter` varies frame to frame; cap it (`settings.mhe_max_iter`) for a bounded budget rather than assuming a fixed cost. See [IK Solvers](IK-solvers.md).
