# Understanding the Output

## Where results land

Each offline run writes to `output/<participant>/<task>/<variant>/`, mirroring the dataset layout. `<variant>` names only the settings that distinguish one run from another — camera count and IK method — so switching solver or cameras writes a new directory instead of overwriting the previous run (e.g. `output/1012/Lifting/4cam_mhe_fatrop/`, `output/1012/Lifting/4cam_sbs/`). Override with `--out DIR`.

## What's in each run directory

| file | contents |
|---|---|
| `joint_angles.csv` | Joint angles per frame, using the standard RT-COSMIK column names (`settings.joint_angles_names`) — the same names and ordering as the reference mocap. |
| `markers.csv` | Triangulated 3D markers per frame, in metres, world frame. |
| `run_info.json` | The full configuration behind the run: cameras, subject, IK type and solver settings, filter, frame counts, and the model's root frame — read by the evaluation tools rather than by hand. |

## REBA scoring

REBA is **not** computed automatically as part of a pipeline run — `rtcosmik.ergonomics.reba` / `reba_offline` is a separate, standalone module. It takes manual posture parameters (load weight, mono- vs. bipodal legs, grip quality, repetition/duration) alongside a run's `joint_angles.csv`, and is run deliberately as a post-hoc step rather than showing up as a column in the pipeline's own output.

## Comparing against reference mocap

`scripts/python/eval/compare_to_mocap.py` is the evaluation tool — see [Running Modes and CLI Reference](./running-modes.md) for the invocation. Runs are **time-aligned** to the mocap first (cameras sync with each other, not with mocap — a per-run lag is estimated from knee-flexion correlation and printed), then compared:

- **Tables**: per-joint and per-marker error, one column per run.
- **Figures** (`--plots DIR`, also writes `errors.csv`): `joint_angle_rmse.png`, `marker_error.png`, `joint_angle_trajectories.png` (captioned per-joint RMSE), `marker_error_distribution.png`.
- **3D replay** (`--meshcat`): every run drawn as the human model it actually solved on.

## Aggregating RMSE across many runs

`scripts/python/eval/compare.py` aggregates the text logs `compare_to_mocap.py` (or `run_multiple_eval.sh`) writes into a run's `logs/*.log` — one log per subject/task, named `Subject_Task.log`. It parses out of each log:

- per-camera-count joint angle error (deg) and marker error (mm)
- root orientation error (deg)
- the free-flyer translation RMSE table (X/Y/Z + mean, in mm)

and prints three levels of averaged tables — per subject (across tasks), per task (across subjects), and one grand overall mean — each a row per camera count:

| column | meaning |
|---|---|
| `Cams` | camera count for this row |
| `Joint(deg)` | mean joint angle RMSE |
| `Marker(mm)` | mean marker RMSE |
| `Orient_Total` | root orientation error |
| `FF_X` / `FF_Y` / `FF_Z` / `FF_Mean` | free-flyer translation RMSE, per axis and mean |

It also saves two grouped bar charts to `--plot-dir` (default `rmse_plots/`): `joint_errs_by_task.png` and `ff_mean_by_task.png`, tasks on the x-axis, one bar per camera-count setup.

```bash
python3 scripts/python/eval/compare.py --root-dir output/1012/Lifting --plot-dir rmse_plots
```

`--root-dir` must contain a `logs/` subfolder; this is for the plain one-log-per-subject/task case, not a horizon-N sweep.

## Diagnosing dropped frames

`scripts/python/eval/frame_drops.py <run>/markers.csv` reads the `Frame_*` counter columns (one per camera, incremented by the camera itself) and looks at how much camera 0's counter jumps between consecutive processed rows — a jump of 1 means nothing was missed, >1 means frames were dropped in between. It reports:

- overall: cameras' frames advanced vs. rows actually processed → **% kept**
- **worst inter-camera skew** within any single row (how far out of sync the cameras' counters are from camera 0's in the same processed frame)
- step stats: median/mean/max, and a count of negative-or-zero steps (a counter anomaly, not a normal drop)
- the run split into **10 deciles**, each showing rows, mean step, % kept, count of skips bigger than `--big` (default 2), and the worst single skip

and classifies the pattern automatically: first-decile mean step > 1.5× the rest → *losses concentrated at the start (warm-up)*; kept% spread under 10 points across deciles → *steady-state, not warm-up*; otherwise → *uneven, look at the worst decile*. That distinction is what the pipeline's own single `kept %` summary line can't give you.

```bash
python3 scripts/python/eval/frame_drops.py output/1012/Lifting/4cam_mhe_fatrop/markers.csv --big 2
```