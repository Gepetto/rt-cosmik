# Troubleshooting

Common problems, grouped by where they show up. For issues rooted in the code itself, see [Known Bugs and Gotchas](../dev-guide/Known%20Bugs.md).

## "My camera doesn't show up"

`rtcosmik.camera.cam_utils.list_cameras()` enumerates capture devices, filtering out non-capture metadata nodes some UVC webcams expose. Confirm the camera shows up at all on the host, and is passed through to the container if you're running in one. If the rig has been recabled, check `cameras.yaml` is present and up to date — RT-COSMIK prefers matching by recorded USB port over the raw device index specifically so a recabled rig doesn't get silently paired with the wrong calibration.

## "The reconstructed skeleton is in the wrong place, or facing the wrong way"

Check the camera pose convention before suspecting the pipeline itself — see [Camera Calibration Procedure § The Convention RT-COSMIK Expects](../functioning/Camera%20Calibration%20Procedure.md). This raises no error on its own; the skeleton is just reconstructed in the wrong place.

## "The Viser/Meshcat window is black or doesn't appear"

If you're on the [devcontainer](Installation.md) setup, this is the stale-Xauthority-on-a-read-only-bind-mount issue — see the Known Errors & Fixes section there for the `xhost`/`XAUTHORITY` workaround.

## "Performance is worse than expected"

- Confirm the container actually has the CPU it thinks it does:
  ```
  docker inspect --format='CPUs (NanoCPUs): {{.HostConfig.NanoCpus}} | Pinning: {{.HostConfig.CpusetCpus}}' <container_name_or_id>
  ```
  Blank `Pinning` means unlimited. On a 32-core host you can comfortably give it more than the default, we did this with 7:
  ```
  docker update --cpuset-cpus="0-7" <container_id_or_name>
  ```
- Read the pipeline's own `[TIME]` line rather than guessing: `pose` (NLF) is normally the dominant cost, well above `ik` — if something else is slower than `pose`, that's the actual thing to chase. See [Threading and Performance](../dev-guide/Repository%20and%20Module%20Map.md).
- Use `scripts/python/eval/frame_drops.py <run>/markers.csv` to see *where* frames were dropped rather than just that some were.

## "Acados fails to import, or `import pinocchio.casadi` breaks"

Two different causes — see [Environment Setup](../dev-guide/Environment.md):
- `ACADOS_SOURCE_DIR` / its `lib/*.so` not on the loader path as **absolute paths** — run `scripts/bash/setup_env.sh --acados`.
- `pip install acados_template` pulling in a pip `casadi` wheel that shadows a from-source CasADi build — install with `--no-deps`, or `pip uninstall -y casadi` to recover.

## "`run_ocp_codegen.py --check` says an artefact is stale"

That's the fingerprint working as intended — something baked into the compiled solver no longer matches the current model/settings. Regenerate for the affected backend/profile; the pipeline will refuse to load a mismatched artefact anyway.
