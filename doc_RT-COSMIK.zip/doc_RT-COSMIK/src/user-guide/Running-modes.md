# Running Modes and CLI Reference

RT-COSMIK exposes several entry-point scripts under `scripts/python/core/` and `scripts/python/eval/`, rather than one monolithic CLI. There is **no batch python script** — sweeping multiple trials is a shell loop (see below).

## Entry points

| Script | What it runs |
|---|---|
| `run_cameras.py` | Live video stream only. No pose estimation. |
| `run_nlf_inference.py` | Pose estimation (NLF) overlaid on the streams. |
| `run_triangulation.py` | Pose estimation + 2D→3D triangulation. |
| `run_pipeline.py` | Full pipeline, single-process: detection → triangulation + filtering → IK → visualization. |
| `run_pipeline_threaded.py` | Full pipeline, with capture/pose/IK split across threads (`reader`/`gpu_worker`/`ik_worker`). |
| `run_ocp_codegen.py` | Generates the compiled IK solver artefacts (only needed for `ik_type="mhe"`). |
| `run_multiple_pipeline.sh` | Shell loop: runs `run_pipeline_threaded.py` over every participant × task × camera-set found under a dataset's `videos/`. |
| `run_multiple_eval.sh` | Shell loop: aggregates per-run logs into RMSE plots via `compare_to_mocap.py`. |

## Selecting a trial

Every offline entry point shares the same flags:

| Flag | Purpose |
|---|---|
| `--dataset DIR` | Dataset root; shorthand for `--cam-params`/`--trial-dir`/`--subject`. |
| `--participant ID` | Participant id within `--dataset`. |
| `--task NAME` | Task name within `--dataset`. |
| `--cam-params DIR` | Explicit calibration directory, instead of `--dataset`/`--participant`. |
| `--trial-dir DIR` | Explicit directory holding `camera_<i>.mp4`, instead of `--dataset`/`--participant`/`--task`. |
| `--subject FILE` | Explicit subject YAML, instead of `--dataset`/`--participant`. |
| `--cameras ID [ID ...]` | Which camera ids to use; the **first** is the triangulation reference frame. |
| `--out DIR` | Output directory (default mirrors the dataset layout under `output/`). |

`run_pipeline.py` additionally takes `--online` (live cameras instead of files), `--replay DIR` (run the online path against recordings, paced as if live), and `--no-save` (visualise only, write no CSVs).

## Choosing an IK method

`settings.ik_type` picks between:
- **`"sbs"`** — sample-by-sample, per-frame IK, solved with Ipopt.
- **`"mhe"`** — moving-horizon estimation over a sliding window, solved by whichever backend `settings.mhe_backend` names: `"fatrop"` (the validated reference) or `"acados"`.

Both `mhe` backends live together on the current branch — there's no separate acados-only branch to switch to. See [IK Solvers](../dev-guide/IK-solvers.md) for solver options, speed/accuracy profiles, and measured numbers.

## Generating the IK solver artefacts

Only needed for `ik_type="mhe"`:

```bash
python3 scripts/python/core/run_ocp_codegen.py --backend acados --profile realtime
python3 scripts/python/core/run_ocp_codegen.py --check   # is a generated artefact stale?
```

## Sweeping several trials

There is no python batch script; `run_multiple_pipeline.sh` shows the pattern (a shell loop calling `run_pipeline_threaded.py` per participant/task/camera-set):

```bash
for p in $(ls /path/to/COMFI/videos); do
  for t in $(ls /path/to/COMFI/videos/$p); do
    python3 scripts/python/core/run_pipeline.py \
        --dataset /path/to/COMFI --participant "$p" --task "$t" || echo "FAILED $p/$t"
  done
done
```

## Comparing runs

- **`compare_to_mocap.py`** — the full evaluation against reference mocap: error tables, figures, 3D Meshcat replay. See [Understanding the Output](Understanding%20the%20Output.md).
- **`compare.py`** — RMSE bar charts from a run's own `logs/` subfolder.
- **`frame_drops.py`** — where dropped camera frames happened in a run.
