# Quickstart

This walks through a first end-to-end run. It assumes RT-COSMIK is installed (see [Installation and Setup](Installation.md)) and the cameras are calibrated (see [Camera Calibration Procedure](../functioning/Camera%20Calibration%20Procedure.md)).

## 1. Check that your cameras are detected

```bash
python3 -c "from rtcosmik.camera.cam_utils import list_cameras; print(list_cameras())"
```

## 2. Sanity-check the raw stream

```bash
python3 scripts/python/core/run_cameras.py --cameras 0 2
```
Live video only, no pose estimation — useful for catching a loose cable before debugging the full pipeline.

## 3. Check pose estimation on its own

```bash
python3 scripts/python/core/run_nlf_inference.py --cameras 0 2
```

## 4. Run a trial offline, against recorded video

```bash
python3 scripts/python/core/run_pipeline.py \
    --dataset /path/to/COMFI --participant 1012 --task Lifting
```

Results land in `output/1012/Lifting/<variant>/`, where `<variant>` encodes the camera count and IK method (e.g. `4cam_mhe_fatrop`) — see [Understanding the Output](Understanding%20the%20Output.md). Meshcat prints a viewer URL at startup for live 3D inspection; pass `--no-save` to visualise only.

## 5. Run live, on cameras

```bash
python3 scripts/python/core/run_pipeline.py --online --cameras 0 2 4 6
```

Cameras are opened through **ffmpeg**, which needs to be on `PATH`. Calibration comes from `settings.cam_calib_path`, or explicitly via `--cam-params`.

Test the live code path without a rig by replaying recordings through it instead of real devices:

```bash
python3 scripts/python/core/run_pipeline.py --online \
  --replay     /path/to/COMFI/videos/1012/Lifting \
  --cam-params /path/to/COMFI/cam_params/1012 \
  --subject    /path/to/COMFI/metadata/1012.yaml \
  --cameras 0 2 4 6
```

## 6. Compare against reference mocap

```bash
python3 scripts/python/eval/compare_to_mocap.py \
    --reference /path/to/COMFI/mocap/aligned/1012/Lifting \
    4cam=output/1012/Lifting/4cam_mhe_fatrop \
    --plots output/1012/eval_Lifting --meshcat
```

## Where to go next

- Seeing an error? Check [Troubleshooting](./troubleshooting.md) first.
- Sweeping more than one trial? There's no batch script — see [Running Modes and CLI Reference](./running-modes.md#sweeping-several-trials) for the shell-loop pattern (or `scripts/bash/run_multiple_pipeline.sh` directly).
