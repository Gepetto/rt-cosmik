# Introduction

## Summary
This book documents the current operation of **RT-COSMIK**, an open-source toolkit developed by the Gepetto team at LAAS-CNRS, along with a summary of the work carried out on it.

RT-COSMIK's goal is to evaluate, in real time, the position of a person's joint centers and joint angles while they perform a task (rehabilitation, sports, or industrial). It can also compute the **REBA** score (Rapid Entire Body Assessment) from the joint centers and angles obtained, which makes it possible to assess how physically demanding a task is and thereby help prevent musculoskeletal disorders.

Unlike other solutions that rely on marker-based methods (stereophotogrammetry), inertial measurement units (IMUs), or that are not real-time — OpenCap, for example — RT-COSMIK uses only low-cost RGB cameras, which makes it easier to use and reduces both installation cost and the burden on the user.

## How to use this book

- **[Understanding RT-COSMIK](functioning/Index.md)** explains the pipeline conceptually — what it does and why — independent of any particular version of the code.
- **The [User Guide](user-guide/Installation.md)** is for anyone running RT-COSMIK: installation, a first end-to-end run, the CLI, reading the output, and troubleshooting.
- **The [Developer Guide](dev-guide/Repository%20and%20Module%20Map.md)** is for anyone changing RT-COSMIK's code: the module map, the threading and performance model, IK solver internals, calibration internals, and a running list of known bugs and gotchas.