## Display / entry-point scripts

The display process depends on which script is used:

- **`run_camera.py`** — shows only the live video stream from the cameras.
- **`run_nlf_inference.py`** — shows NLF's results by overlaying the estimated points on the multiple video streams, whether from the cameras directly or from previously recorded videos.
- **`run_triangulation.py`** — plots a point cloud in red for camera 0 and another in blue for the triangulation. This point cloud should correspond to the tracked person's movements in the videos or camera feeds. To do this, the script uses the video streams and the NLF pose estimator, and applies a homogeneous transformation matrix to convert the second camera's points into the first camera's reference frame — turning these 2D points into 3D points in the first camera's frame.
- **`run_pipeline.py`** — runs the full pipeline. This includes the same steps as `run_triangulation.py`, then simulates the person's position using a mannequin built with the **Pinocchio** library, whose URDF was hand-coded.

There are also several benchmark files used to measure execution times for the different parts of the RT-COSMIK pipeline, notably the various MMPose stages, the triangulation step, and the pipeline as a whole.

See [Running Modes and CLI Reference](../user-guide/running-modes.md) for how to invoke each of these scripts and their flags.

## Dataset

The dataset (**COMFI**) makes it possible to test changes to RT-COSMIK without using the cameras directly: several tasks performed by different participants, recorded on video alongside synchronized motion capture, force data, calibration, and per-participant metadata.

It is organized **by category first, then by participant, then (where relevant) by task** — not by date. Top-level categories under `COMFI/`:

- **`cam_params/<id>/`** — camera calibration for that participant's session (not split by task): pairwise camera-to-camera extrinsics under `extrinsics/cam_to_cam/camera_X_to_camera_Y.yaml`, and the camera-to-world extrinsics plus the Aruco calibration images used to derive them under `extrinsics/cam_to_world/camera_0/` (`camera_0_extrinsics.yaml`, `images/*.jpg`).
- **`videos/<id>/<task>/`** — one `.mp4` and one matching `_timestamps.csv` per camera, at ≈40 Hz (e.g. `camera_0.mp4` / `camera_0_timestamps.csv`).
- **`forces/<raw|aligned>/<id>/<task>/`** — mirrors the `mocap/` raw/aligned split: a single `<task>_devices.csv` per participant/task (e.g. `forces/raw/1847/Screwing/Screwing_devices.csv`, `forces/aligned/1847/Screwing/Screwing_devices.csv`).
- **`mocap/<raw|aligned>/<id>/<task>/`** — optical motion capture: 3D marker positions, 3D estimated marker positions, joint center positions, and joint angles.
  - `raw/` (100 Hz, C3D + CSV + VSK) — `joint_angles.csv`, `joint_center.csv`, `markers_trajectories.csv`, and the task's `.c3d` file, plus a per-**participant** (not per-task) `<id>.vsk`.
  - `aligned/` (40 Hz, synchronized with the cameras) — the same three CSVs plus `markers_model_trajectories.csv`.
- **`metadata/<id>/`** — a per-participant `<id>.yaml` descriptor and a scaled URDF at `urdf/<id>_scaled.urdf`.

Participants are identified by a numeric ID (e.g. `1847`), tasks by name (e.g. `Screwing`), and cameras by even index (`camera_0`, `camera_2`, `camera_4`, `camera_6`) — consistent with the pairwise calibration convention in [Camera Calibration Procedure](Camera%20Calibration%20Procedure.md). For a given task, there are as many videos as there are cameras.

**Force and robot data are not recorded for every task.** Don't assume a given participant/task combination has a `forces/` entry (or robot data, where applicable) — check before relying on it.
