# Overview of RT-COSMIK

There are currently two versions of RT-COSMIK, which use two different Human Pose Estimators (HPE):

- **MMPose** — however, this Python library is no longer maintained.
- **NLF** (Neural Localizer Field) — still maintained and more advanced.

The following sections describe each version's pipeline in detail.

## MMPose version of RT-COSMIK

MMPose first detects whether a person is present in an image (detect). If so, it isolates the portion of the image containing the person with a bounding box and detects keypoints within it. These keypoints correspond to pre-selected key points used to evaluate the joint center positions and angles. For this purpose, the camera video streams are used to triangulate the keypoints. Triangulation is weighted based on the confidence score provided directly by MMPose  for the 2D points, the consistency of the 2D points across all active cameras (which require similar coordinates), and low speed peaks between time steps $t$ and $t+1$.

A constant-velocity Kalman filter is applied to the resulting triangulated points.

To further improve point quality, a Recurrent Neural Network with Long Short-Term Memory (LSTM), adapted from OpenCap, is used. The final layer of this LSTM was retrained on videos of industrial tasks to refine the results.

Once filtered, the points are triangulated to transition from 2D to 3D within the coordinate frame of the primary camera.

A biomechanical human body model with 36 degrees of freedom was built for the MMPose version of RT-COSMIK. It does not account for thoracic joint, wrist, or hand movements.

To calibrate this model, the participant remains stationary.

Finally, to compute joint center positions and angles, RT-COSMIK applies an inverse kinematics model to the triangulated points while accounting for velocity and amplitude joint constraints, minimizing the residual (the gap between predicted model values and real observations) between the two. `settings.ik_type` picks between two ways of doing this: **`"sbs"`** (sample-by-sample, one frame at a time), solved with IPOPT (Interior Point OPTimizer); and **`"mhe"`** (moving-horizon estimation, over a sliding window of frames), solved by either **Fatrop** or **Acados**, both SQP (Sequential Quadratic Programming) solvers — see [IK Solvers](../dev-guide/IK-solvers.md) for the two backends' settings and measured speed/accuracy.

Here is a diagram summarizing how RT-COSMIK operates with MMPose:

![MMPose pipeline diagram](../img/MMPose_version.png)

## NLF version of RT-COSMIK

Whith NLF, the thoracic joints, wrist joints are taken into account, so there's 43 degrees of freedom.
The second version of RT-COSMIK follows the same workflow, but replaces MMPose detect with YOLO and MMPose's keypoint detection with NLF, as shown below:

![NLF pipeline diagram](../img/NLF_version.png)
In this version, YOLO plays the same role as MMPose detect: it detects whether a person is present in an image. If so, it passes the contents of the bounding box to NLF. Unlike MMPose, NLF provides a point mesh (a point cloud that breaks down a shape into simpler elements). RT-COSMIK then extracts the pre-selected keypoints. The biomechanical model features 36 degrees of freedom in this version of RT-COSMIK, as thoracic joint and wrist movements are not locked. The remaining workflow is identical.

## Process Architecture

Regardless of which version is used, the overall process organization stays the same:

- Each camera is managed by its own process, which transmits its video stream to the pipeline (the part of the program that performs the processing, from MMPose `detect` or YOLO through to obtaining the joint center positions and angles).
- There is also one additional process per camera that records that camera's video stream.
- Finally, there is a display process.

![Process architecture diagram](../img/processus.png)