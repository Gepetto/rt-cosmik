# Camera Calibration Procedure

Camera calibration is performed using a dedicated GitHub repository. You need to specify the number of rows and columns of the checkerboard pattern, counting the number of interior squares. Square dimensions follow OpenCV's standard calibration conventions.

To run the calibration, a script displays the cameras' live video feed and lets you capture photos, pressing `q` to stop capturing. About twenty photos are taken with the checkerboard at different orientations and heights.

**Target accuracy:**
- Intrinsic parameters: ~0.22 pixel
- Extrinsic parameters: ~0.4 pixel

From this calibration, you obtain YAML configuration files containing the cameras' intrinsic and extrinsic parameters, along with files giving the homogeneous transformation matrices between the different cameras used in RT-COSMIK.

Note that cameras are calibrated in pairs. For example, with cameras c0, c2, c4, and c6:
- c0 has a homogeneous transformation matrix to c2,
- c4 has a homogeneous transformation matrix to c6,
- and then from c4 to c0.

Finally, to obtain the world reference frame, an Aruco marker mounted on a wand is pointed at known reference positions (see Stage 2 below) — not left in a fixed, static placement.

To calibrate a multi-camera rig using these scripts, follow this two-stage workflow: **Stage 1** estimates lens intrinsics and relative stereo poses via `calibrate_cameras.py`, and **Stage 2** anchors the rig to a physical global coordinate frame via `set_world_frame.py`.

# Phase 1: Camera & Stereo Pair Calibration (`calibrate_cameras.py`)

This step captures checkerboard images to solve each camera's intrinsic parameters (focal length, optical center, distortion) and computes adjacent camera relative poses (extrinsics).

## a) Capture and Process Live Streams

Ensure all cameras are connected. Pass camera indices in ring/rig order so adjacent views overlap.
 Please ensure to have overlapping views, that the checkerboard is visible in full in all photos and that there is not light reflection on the checkerboard.

Bash

```
python3 scripts/calibrate_cameras.py --cameras 0 2 4 6
```

1. A live tiled window showing all camera feeds will open.
    
2. Position a calibration checkerboard so it is visible to adjacent camera pairs.
    
3. Press **SPACE** to save a synchronized frame set across all cameras. Capture multiple angles and positions.
    
4. Press **`q`** or **`ESC`** when finished. 

The script automatically solves intrinsics and pairwise stereo extrinsics ie camera_0_to_camera_2.yaml, camera_2_to_camera_4.yaml, and camera_4_to_camera_6.yaml. This also give directly the camera_0_to_camera_4.yaml and camera_0_to_camera_6.yaml.

## b) Calibrate Using Existing Disk Images

If image datasets are already stored in `images_calib_cam_<i>/color/`:

Bash

```
python3 scripts/calibrate_cameras.py --cameras 0 2 --from-images
```

Press `q` to quit the OpenCV window, that shows the pared pixel, so the code continue properly.
This parameter also automatically solves intrinsics and pairwise stereo extrinsics ie camera_0_to_camera_2.yaml, camera_2_to_camera_4.yaml, and camera_4_to_camera_6.yaml.

# Phase 2: Anchor the World Frame (`set_world_frame.py`)

This step points an ArUco-marked wand at target reference positions to establish the origin and axes of the world coordinate system.

## a) Ground Coordinate Frame (3 Pointed Positions)

To anchor the origin to a frame marked on the floor, place the wand tip sequentially at **3 ground points**:

Bash

```
# Live capture
python3 scripts/set_world_frame.py --cameras 0 2 4 6

# Offline from existing images
python3 scripts/set_world_frame.py --cameras 0 2 --from-images
```

1. Position the wand at **Position 1** and press **SPACE**.
    
2. Repeat for **Positions 2 and 3**. The window displays a live overlay showing the projected wand tip.
    

## b) Robot Base Coordinate Frame (4 Pointed Positions)

To anchor the global origin directly to a robot base, use the `--robot` flag. This routine expects **4 pointed positions**:

Bash

```
python3 scripts/set_world_frame.py --cameras 0 2 4 6 --robot
```

Both of those option give the extrinsics of the camera_\<id>\_extrincs.yaml. Which enable to have the position of all cameras in the world.

# Primary Command Line Arguments

|**Argument**|**Script**|**Function**|
|---|---|---|
|`--cameras`|Both|Space-separated list of camera hardware IDs (e.g., `0 2 4`). The first ID becomes the reference camera.|
|`--from-images`|Both|Skips video stream acquisition and uses existing images saved on disk.|
|`--no-show`|Both|Disables visualization GUI windows (required for headless/remote SSH sessions).|
|`--out`|Both|Target folder output path (defaults to `config/cam_params/`).|
|`--install [PATH]`|Both|Automatically exports files to RT-COSMIK's setup configuration directory.|
|`--robot`|`set_world_frame.py`|Sets world origin to robot base (4 wand positions) instead of ground (3 wand positions).|
|`--labels`|`calibrate_cameras.py`|Assigns human-readable names to cameras (e.g., `--labels 0=front_left 2=front_right`).|

# Calibration Requirements & Sanity Checks

- **Minimum Shared Views:** Stereo pair optimization requires at least **6 shared board captures** between adjacent cameras. If fewer exist, capture additional overlapping views.
    
- **Visual Verification:** Check the generated image `world_frame_check.png`. The drawn RGB axes (**X=Red, Y=Green, Z=Blue**) should sit flush on the target ground/robot reference origin.
    
- **Intrinsic parameters**: The error for the intrinsics parameter should be around 0.22 pixel.
- **Extrinsic parameters**: The error for the extrinsic parameter should be around 0.4 pixel.
  If the errors are above this, then redo the calibration procedure. Please ensure to have overlapping views, that the checkerboard is visible in full in all photos and that there is not light reflection on the checkerboard.

# The Convention RT-COSMIK Expects

RT-COSMIK reads back the pose of each camera **in the world frame**, one convention everywhere: `R` (3×3, the camera's orientation in world coordinates) and `T` (3×1, the camera's actual physical position in the room, in metres), such that `p_world = R @ p_cam + T`.

This matters because `cv2.solvePnP` and most raw ArUco helpers give the **opposite** transform (world-in-camera-frame) — invert before saving (`R = R_cv.T`, `T = -R_cv.T @ t_cv`) if you're ever deriving extrinsics outside `calibrate_cameras.py`/`set_world_frame.py`, which already handle this correctly.

A wrong transform doesn't raise an error — the skeleton is just reconstructed in the wrong place and orientation. Beyond `world_frame_check.png` above, sanity-check any calibration directly:

```python
from rtcosmik.camera.cam_utils import describe_camera_placement
describe_camera_placement("<dataset>/cam_params/<participant>")
```

If a camera's `T` comes out near zero or at an implausible height, its transform is inverted.

Only the **reference** camera (the first id passed to `--cameras`) is anchored directly by `set_world_frame.py`; every other camera is placed relative to it by chaining `calibrate_cameras.py`'s pairwise stereo results. If no anchor is present at all, the reference camera's own frame silently becomes the world frame (with a warning) — joint angles are unaffected, but positions come out in camera coordinates rather than room coordinates.