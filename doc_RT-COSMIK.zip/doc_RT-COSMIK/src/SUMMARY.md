# Summary

[Introduction](Introduction.md)

# User Guide

- [Installation](User-guide/Installation.md)
- [Quickstart](User-guide/Quickstart.md)
- [Running Modes](User-guide/Running-modes.md)
- [Troubleshooting](User-guide/Troubleshooting.md)
- [Understanding the Output](User-guide/Understanding%20the%20Output.md)

# Functioning

- [Index](Functioning/Index.md)
- [Camera Calibration Procedure](Functioning/Camera%20Calibration%20Procedure.md)
- [Display Scripts and Dataset](Functioning/Display%20Scripts%20and%20Dataset.md)

# Developer Guide

- [IK Solvers](Dev-guide/IK-solvers.md)
- [Repository and Module Map](Dev-guide/Repository%20and%20Module%20Map.md)
- [Known Bugs](Dev-guide/Known%20Bugs.md)